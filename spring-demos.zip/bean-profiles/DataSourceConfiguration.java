import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
public class DataSourceConfiguration {

	
	@Bean
	@Profile({"dev","test"})
	public DataSource oracleDataSource() {
		return new OracleDataSource();
	}

	@Bean
	@Profile({"qa","prod"})
	public DataSource sybaseDataSource() {
		return new SybaseDataSource();
	}
}
