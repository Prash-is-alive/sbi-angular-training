public interface DataSource {

}
