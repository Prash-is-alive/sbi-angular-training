public class SybaseDataSource implements DataSource {

}
