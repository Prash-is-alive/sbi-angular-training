package com.training.controller;

import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import com.training.entity.Person;
import com.training.entity.PersonDTO;

@Component
public class PersonDTOMapper extends PropertyMap<Person, PersonDTO> {

	@Override
	protected void configure() {
		map().setCity(source.getAddress().getCity());
		map().setPincode(source.getAddress().getPincode());
	}
}
