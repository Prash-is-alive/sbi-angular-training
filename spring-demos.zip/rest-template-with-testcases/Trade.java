package com.training.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PostPersist;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name = "TBL_TRADE")
@EntityListeners(TradeListener.class)
public class Trade {

	@Id
	@GeneratedValue
	private int tradeId;
	
	@NotNull
	@Size(min = 2, max=10)
	@Pattern(regexp="[A-Z]*")
	private String region;
	
	@Column(name = "DATE_OF_TRANSACTION")
	@Temporal(TemporalType.TIMESTAMP)
	private Date date;
	
	private double amount;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "AGENT_ID", nullable=false)
	private Agent agent;
	
	
	/*@PrePersist
	public void beforeInsert() {
		System.out.println("beforeInsert");
	}

	@PostPersist
	public void afterInsert() {
		System.out.println("afterInsert");
	}*/

	//@PreUpdate, @PostUpdate, @PreRemove, @PostRemove, @PostLoad
	

	public int getTradeId() {
		return tradeId;
	}
	public void setTradeId(int tradeId) {
		this.tradeId = tradeId;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
}
