package com.training.test;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.training.App;
import com.training.entity.Trade;
import com.training.repository.TradeRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@SpringBootTest(classes=App.class)
//@ActiveProfiles("test")
public class TradeRepositoryTest {

	@Autowired private TestEntityManager entityManager;

	@Autowired private TradeRepository tradeRepository;
	
	@Test
	public void testCreateNewTradeRecordInDatabase() {
		Trade trade = new Trade();
		trade.setRegion("NY");
		trade.setDate(new Date());
		trade.setAmount(4500);
		
		entityManager.persist(trade);
		//tradeRepository.save(trade);
		
		Iterable<Trade> fetchedTrades = tradeRepository.findAll();
		//bad thing we are doing here
		for(Trade fetchedTrade : fetchedTrades)
			System.out.println(fetchedTrade);
	}

}





