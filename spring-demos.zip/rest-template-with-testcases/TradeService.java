package com.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.training.entity.Trade;
import com.training.repository.TradeRepository;

@Service
public class TradeService {

	@Autowired
	private TradeRepository tradeRepository;
	
	@Autowired
	private SomeCode someCode;
	
	@Transactional //rollbackFor=UnExceptionException.class)
	public void processNewTrade(Trade trade) {
		//business logic/rules/validation here, missing right now
		tradeRepository.save(trade);
		
		someCode.someLogicHere();
	}
}

@Component
class SomeCode {
	
	@Transactional(propagation=Propagation.REQUIRED)
	void someLogicHere() {//throws UnExceptionException {
		
	}
}