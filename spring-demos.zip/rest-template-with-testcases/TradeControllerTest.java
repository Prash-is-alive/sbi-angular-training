package com.training.test;

import static org.mockito.BDDMockito.given;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.training.App;
import com.training.entity.Trade;
import com.training.service.RemoteBankService;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT, classes=App.class)

@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)

//@AutoConfigureMockMvc()
//@WebMvcTest(TradeController.class)
//@AutoConfigureWebTestClient
public class TradeControllerTest {

	//@Autowired
	//private MockMvc mvc;
	
	@Autowired
	//private RestTemplateBuilder builder;
	private TestRestTemplate restTemplate;
	
	@MockBean
	private RemoteBankService service;
	
	@Test
	public void test() throws Exception {
		given(service.communicateWithBankForNewTrade(new Trade()))
				.willReturn("Trade record acknowledged by Bank");
		
		Trade trade = new Trade();
		trade.setRegion("NY");
		trade.setDate(new Date());
		trade.setAmount(4500);
		
		
		RestTemplate restTemplate = builder.build();
		String response = restTemplate.postForObject("/trade/postNewTrade", trade, String.class);
		System.out.println(response);
		
		/*webClient.post()
					.uri("/trade/postNewTrade")
					.exchange()
					.expectBody(String.class)
					.isEqualTo("Trade record created successfully");*/

		
		/*mvc.perform(
				post("/trade/postNewTrade")
				.accept(MediaType.TEXT_PLAIN))
				.andExpect(status().isOk())
				.andExpect(content().string("Trade record created successfully"));*/
		
	}

}
