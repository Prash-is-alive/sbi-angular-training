package com.training.repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.training.entity.Customer;

public class CustomCustomerCriteria { //implements Specification<Customer> {

	public static Specification<Customer> customersBasedOnEmail(String  email) {
		Specification<Customer> s = (root,query,criteriaBuilder) -> {
			return criteriaBuilder.like(root.<String>get("email"), "%" + email + "%"); 
		};
		return s;
	}

	/*public Predicate toPredicate(Root<Customer> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {

		return criteriaBuilder.like(root.<String>get("email"),"%gmail%"); 
		
	}*/

		
}
