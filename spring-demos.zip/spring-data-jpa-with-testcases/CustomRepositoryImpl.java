package com.training.repository;

import javax.persistence.EntityManager;

import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;

public class CustomRepositoryImpl<T,ID> extends SimpleJpaRepository<T, ID> implements CustomRepository<T,ID> {

	private EntityManager entityManager;
	private String entityName;
	
	public CustomRepositoryImpl(JpaEntityInformation<T, ?> entityInformation, EntityManager entityManager) {
		super(entityInformation, entityManager);
		this.entityName = entityInformation.getEntityName();
		this.entityManager = entityManager;
	}

	public void refresh(T t) {
		//Object obj = entityManager.createQuery("select obj from " + entityName + " where id = " + id).getSingleResult();
		entityManager.refresh(t);
	}

	
}
