package com.training.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.training.model.FlightDetails;

@Service
public class AirlinesService {

	//@Async
	public FlightDetails getAvailableFlights(String source, String destination) {
		try { Thread.sleep(20000); } catch(Exception e) { }
		return new FlightDetails();
	}

}
