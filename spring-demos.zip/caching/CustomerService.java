package com.training.service;

import org.hibernate.annotations.Cache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.training.entity.Customer;
import com.training.repository.CustomerRepository;

@Service
@Transactional
public class CustomerService implements ICustomerService {

	@Autowired
	private CustomerRepository customerRepository;
	
	@Override
	@CacheEvict("customers.cache")
	public void register(Customer customer) {
		customerRepository.save(customer);
	}
	
	@Cacheable(value="customer.cache",key="#id")//, condition="#id > 1111")
	public Customer customer(int id) {
		return customerRepository.findById(id).get();
	}
	
	@Override
	@Cacheable("customers.cache")
	public Iterable<Customer> registeredCustomers() {
		return customerRepository.findAll();
	}
	
	@Scheduled(fixedRate = 30000)
	public void processCustomerData() {
		Iterable<Customer> customers = customerRepository.findAll();
		for(Customer customer : customers)
			System.out.println(customer);
	}
	
}
