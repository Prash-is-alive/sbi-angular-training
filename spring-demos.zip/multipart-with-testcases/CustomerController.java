package com.training.controller;

import java.io.File;
import java.io.FileOutputStream;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.model.Customer;

@RestController
@RequestMapping("/customer/*")
public class CustomerController {

	@RequestMapping(path="/new", method=RequestMethod.POST, 
					consumes="multipart/form-data",
					produces="text/plain")
	public String register(@RequestPart("customer") String customerData,
							@RequestPart("profilePic") MultipartFile file) throws Exception {
		
		Customer customer = new ObjectMapper().readValue(customerData, Customer.class); 
		customer.setProfilePic(file.getBytes());
		
		String uploadedFolderLocation = "/Users/majrul/Documents/uploads/";
		FileCopyUtils.copy(file.getInputStream(), new FileOutputStream(uploadedFolderLocation + customer.getName() +".jpg"));
		
		System.out.println(customer);
		
		return "Customer has been registered successfully";
				
	}
}
