package com.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class JwtDemoAppTests {

	@Test
	void contextLoads() {
	}

}
