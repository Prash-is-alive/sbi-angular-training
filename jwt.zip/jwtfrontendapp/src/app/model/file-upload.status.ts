export class FileUploadStatus {
  public status: string;
  public  percentage: number;

  constructor() {
    this.status = '';
    this.percentage = 0;
  }
}
