export enum HeaderType {
  AUTHORIZATION = 'Authorization',
  JWT_TOKEN = 'Jwt-Token'
}
