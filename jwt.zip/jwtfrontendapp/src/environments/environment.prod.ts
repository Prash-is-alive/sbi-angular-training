export const environment = {
  production: true,
  apiUrl: 'PROD URL'
};
